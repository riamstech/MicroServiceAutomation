Demonstration of Rest-Assured and Cucumber for web services automation. Full tutorial available at http://angiejones.tech/rest-assured-with-cucumber-using-bdd-for-web-services-automation
